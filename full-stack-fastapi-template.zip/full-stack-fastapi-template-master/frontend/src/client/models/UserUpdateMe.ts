/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type UserUpdateMe = {
    full_name?: (string | null);
    email?: (string | null);
};
