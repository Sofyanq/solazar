/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { ItemOut } from './ItemOut';

export type ItemsOut = {
    data: Array<ItemOut>;
    count: number;
};
