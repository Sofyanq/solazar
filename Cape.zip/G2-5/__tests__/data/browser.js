export const browser = [
  {
    name: 'Internet Explorer',
    value: 26,
    url: 'data/ie.png',
  },
  {
    name: 'Chrome',
    value: 40,
    url: 'data/chrome.png',
  },
  {
    name: 'Firefox',
    value: 30,
    url: 'data/firefox.png',
  },
  {
    name: 'Safari',
    value: 24,
    url: 'data/safari.png',
  },
  {
    name: 'Opera',
    value: 15,
    url: 'data/opera.png',
  },
  {
    name: 'Undetectable',
    value: 8,
    url: 'data/undetectable.png',
  },
];
