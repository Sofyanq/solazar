export const fruits = [
  { type: 'Apple', year: '2001', value: 260 },
  { type: 'Orange', year: '2001', value: 100 },
  { type: 'Banana', year: '2001', value: 90 },
  { type: 'Apple', year: '2002', value: 210 },
  { type: 'Orange', year: '2002', value: 150 },
  { type: 'Banana', year: '2002', value: 30 },
]