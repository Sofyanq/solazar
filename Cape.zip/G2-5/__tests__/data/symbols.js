export const symbols = [
  { date: '2000-02-02', close: 30, symbol: 'foo1' },
  { date: '2000-02-03', close: 34, symbol: 'foo1' },
  { date: '2000-02-04', close: 31, symbol: 'foo2' },
  { date: '2000-02-05', close: 32, symbol: 'foo2' }
]