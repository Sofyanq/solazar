export const acmeCropIncome = [
  { x: 'Net Sales', value: 5085000, start: 0, end: 5085000 },
  { x: 'Cost of Sales', value: -1250450, start: 5085000, end: 3834550 },
  { x: 'Operating Expenses', value: -2350050, start: 3834550, end: 1484500 },
  { x: 'Other Income', value: 750000, start: 1484500, end: 2234500 },
  { x: 'Extraordinary Gain', value: -230050, start: 2234500, end: 2004450 },
  { x: 'Interest Expense', value: -500000, start: 2004450, end: 1504450 },
  { x: 'Taxes', value: 490000, start: 1504450, end: 1994450 },
  { x: 'Net Income', isTotal: true, value: 1994450, start: 0, end: 1994450 },
];
