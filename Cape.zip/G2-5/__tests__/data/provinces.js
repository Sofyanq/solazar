export const provinces =[
  {
    "idx": 0,
    "number": 2445,
    "province": "四川省",
    "type": "number",
    "sub_type": "xx"
  },
  {
    "idx": 0,
    "number": 21094.69,
    "province": "四川省",
    "type": "price",
    "sub_type": "yy"
  },
   {
    "idx": 1,
    "number": 1244,
    "province": "四川省",
    "type": "number",
    "sub_type": "xx"
  },
  {
    "idx": 1,
    "number": 12756,
    "province": "四川省",
    "type": "price",
    "sub_type": "yy"
  },
  {
    "idx": 2,
    "number": 2244,
    "province": "四川省",
    "type": "number",
    "sub_type": "xx"
  },
  {
    "idx": 2,
    "number": 19756.88,
    "province": "四川省",
    "type": "price",
    "sub_type": "yy"
  },
  {
    "idx": 3,
    "number": 244,
    "province": "四川省",
    "type": "number",
    "sub_type": "xx"
  },
  {
    "idx": 4,
    "number": 1975,
    "province": "四川省",
    "type": "price",
    "sub_type": "yy"
  },
  {
    "idx": 4,
    "number": 4004,
    "province": "四川省",
    "type": "number",
    "sub_type": "xx"
  },
]