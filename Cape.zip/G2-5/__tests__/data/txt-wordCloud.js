export const text =[
  {
      "text": "freedom",
      "value": 67
  },
  {
      "text": "negro",
      "value": 58
  },
  {
      "text": "one",
      "value": 54
  },
  {
      "text": "let",
      "value": 54
  },
  {
      "text": "ring",
      "value": 51
  },
  {
      "text": "nation",
      "value": 49
  },
  {
      "text": "day",
      "value": 49
  },
  {
      "text": "dream",
      "value": 49
  },
  {
      "text": "come",
      "value": 47
  },
  {
      "text": "every",
      "value": 47
  },
  {
      "text": "today",
      "value": 45
  },
  {
      "text": "go",
      "value": 45
  },
  {
      "text": "back",
      "value": 45
  },
  {
      "text": "justice",
      "value": 42
  },
  {
      "text": "must",
      "value": 42
  },
  {
      "text": "satisfied",
      "value": 42
  },
  {
      "text": "able",
      "value": 42
  },
  {
      "text": "together",
      "value": 39
  },
  {
      "text": "long",
      "value": 36
  },
  {
      "text": "men",
      "value": 36
  },
  {
      "text": "white",
      "value": 36
  },
  {
      "text": "now",
      "value": 36
  },
  {
      "text": "years",
      "value": 33
  },
  {
      "text": "great",
      "value": 33
  },
  {
      "text": "free",
      "value": 33
  },
  {
      "text": "check",
      "value": 33
  },
  {
      "text": "america",
      "value": 33
  },
  {
      "text": "time",
      "value": 33
  },
  {
      "text": "children",
      "value": 33
  },
  {
      "text": "new",
      "value": 33
  },
  {
      "text": "faith",
      "value": 33
  },
  {
      "text": "american",
      "value": 30
  },
  {
      "text": "hope",
      "value": 30
  },
  {
      "text": "hundred",
      "value": 30
  },
  {
      "text": "later",
      "value": 30
  },
  {
      "text": "still",
      "value": 30
  },
  {
      "text": "land",
      "value": 30
  },
  {
      "text": "black",
      "value": 30
  },
  {
      "text": "god",
      "value": 30
  },
  {
      "text": "mississippi",
      "value": 30
  },
  {
      "text": "mountain",
      "value": 30
  },
  {
      "text": "join",
      "value": 25
  },
  {
      "text": "stand",
      "value": 25
  },
  {
      "text": "injustice",
      "value": 25
  },
  {
      "text": "words",
      "value": 25
  },
  {
      "text": "note",
      "value": 25
  },
  {
      "text": "rights",
      "value": 25
  },
  {
      "text": "people",
      "value": 25
  },
  {
      "text": "make",
      "value": 25
  },
  {
      "text": "rise",
      "value": 25
  },
  {
      "text": "valley",
      "value": 25
  },
  {
      "text": "brotherhood",
      "value": 25
  },
  {
      "text": "sweltering",
      "value": 25
  },
  {
      "text": "never",
      "value": 25
  },
  {
      "text": "alabama",
      "value": 25
  },
  {
      "text": "georgia",
      "value": 25
  },
  {
      "text": "state",
      "value": 25
  },
  {
      "text": "little",
      "value": 25
  },
  {
      "text": "made",
      "value": 25
  },
  {
      "text": "sing",
      "value": 25
  },
  {
      "text": "last",
      "value": 25
  },
  {
      "text": "history",
      "value": 21
  },
  {
      "text": "came",
      "value": 21
  },
  {
      "text": "slaves",
      "value": 21
  },
  {
      "text": "end",
      "value": 21
  },
  {
      "text": "life",
      "value": 21
  },
  {
      "text": "segregation",
      "value": 21
  },
  {
      "text": "cash",
      "value": 21
  },
  {
      "text": "promissory",
      "value": 21
  },
  {
      "text": "liberty",
      "value": 21
  },
  {
      "text": "color",
      "value": 21
  },
  {
      "text": "insufficient",
      "value": 21
  },
  {
      "text": "funds",
      "value": 21
  },
  {
      "text": "refuse",
      "value": 21
  },
  {
      "text": "believe",
      "value": 21
  },
  {
      "text": "urgency",
      "value": 21
  },
  {
      "text": "racial",
      "value": 21
  },
  {
      "text": "content",
      "value": 21
  },
  {
      "text": "continue",
      "value": 21
  },
  {
      "text": "struggle",
      "value": 21
  },
  {
      "text": "dignity",
      "value": 21
  },
  {
      "text": "allow",
      "value": 21
  },
  {
      "text": "creative",
      "value": 21
  },
  {
      "text": "physical",
      "value": 21
  },
  {
      "text": "force",
      "value": 21
  },
  {
      "text": "brothers",
      "value": 21
  },
  {
      "text": "realize",
      "value": 21
  },
  {
      "text": "destiny",
      "value": 21
  },
  {
      "text": "walk",
      "value": 21
  },
  {
      "text": "police",
      "value": 21
  },
  {
      "text": "brutality",
      "value": 21
  },
  {
      "text": "cities",
      "value": 21
  },
  {
      "text": "vote",
      "value": 21
  },
  {
      "text": "york",
      "value": 21
  },
  {
      "text": "like",
      "value": 21
  },
  {
      "text": "mighty",
      "value": 21
  },
  {
      "text": "jail",
      "value": 21
  },
  {
      "text": "suffering",
      "value": 21
  },
  {
      "text": "work",
      "value": 21
  },
  {
      "text": "south",
      "value": 21
  },
  {
      "text": "knowing",
      "value": 21
  },
  {
      "text": "despair",
      "value": 21
  },
  {
      "text": "even",
      "value": 21
  },
  {
      "text": "live",
      "value": 21
  },
  {
      "text": "true",
      "value": 21
  },
  {
      "text": "meaning",
      "value": 21
  },
  {
      "text": "sons",
      "value": 21
  },
  {
      "text": "former",
      "value": 21
  },
  {
      "text": "heat",
      "value": 21
  },
  {
      "text": "boys",
      "value": 21
  },
  {
      "text": "girls",
      "value": 21
  },
  {
      "text": "hands",
      "value": 21
  },
  {
      "text": "hill",
      "value": 21
  },
  {
      "text": "places",
      "value": 21
  },
  {
      "text": "stone",
      "value": 21
  },
  {
      "text": "thee",
      "value": 21
  },
  {
      "text": "mountainside",
      "value": 21
  },
  {
      "text": "happy",
      "value": 15
  },
  {
      "text": "greatest",
      "value": 15
  },
  {
      "text": "demonstration",
      "value": 15
  },
  {
      "text": "five",
      "value": 15
  },
  {
      "text": "score",
      "value": 15
  },
  {
      "text": "ago",
      "value": 15
  },
  {
      "text": "symbolic",
      "value": 15
  },
  {
      "text": "shadow",
      "value": 15
  },
  {
      "text": "signed",
      "value": 15
  },
  {
      "text": "emancipation",
      "value": 15
  },
  {
      "text": "proclamation",
      "value": 15
  },
  {
      "text": "momentous",
      "value": 15
  },
  {
      "text": "decree",
      "value": 15
  },
  {
      "text": "beacon",
      "value": 15
  },
  {
      "text": "light",
      "value": 15
  },
  {
      "text": "millions",
      "value": 15
  },
  {
      "text": "seared",
      "value": 15
  },
  {
      "text": "flames",
      "value": 15
  },
  {
      "text": "withering",
      "value": 15
  },
  {
      "text": "joyous",
      "value": 15
  },
  {
      "text": "daybreak",
      "value": 15
  },
  {
      "text": "night",
      "value": 15
  },
  {
      "text": "captivity",
      "value": 15
  },
  {
      "text": "sadly",
      "value": 15
  },
  {
      "text": "crippled",
      "value": 15
  },
  {
      "text": "manacles",
      "value": 15
  },
  {
      "text": "chains",
      "value": 15
  },
  {
      "text": "discrimination",
      "value": 15
  },
  {
      "text": "lives",
      "value": 15
  },
  {
      "text": "lonely",
      "value": 15
  },
  {
      "text": "island",
      "value": 15
  },
  {
      "text": "poverty",
      "value": 15
  },
  {
      "text": "midst",
      "value": 15
  },
  {
      "text": "vast",
      "value": 15
  },
  {
      "text": "ocean",
      "value": 15
  },
  {
      "text": "material",
      "value": 15
  },
  {
      "text": "prosperity",
      "value": 15
  },
  {
      "text": "languishing",
      "value": 15
  },
  {
      "text": "corners",
      "value": 15
  },
  {
      "text": "society",
      "value": 15
  },
  {
      "text": "finds",
      "value": 15
  },
  {
      "text": "exile",
      "value": 15
  },
  {
      "text": "dramatize",
      "value": 15
  },
  {
      "text": "shameful",
      "value": 15
  },
  {
      "text": "condition",
      "value": 15
  },
  {
      "text": "sense",
      "value": 15
  },
  {
      "text": "capital",
      "value": 15
  },
  {
      "text": "architects",
      "value": 15
  },
  {
      "text": "republic",
      "value": 15
  },
  {
      "text": "wrote",
      "value": 15
  },
  {
      "text": "magnificent",
      "value": 15
  },
  {
      "text": "constitution",
      "value": 15
  },
  {
      "text": "declaration",
      "value": 15
  },
  {
      "text": "independence",
      "value": 15
  },
  {
      "text": "signing",
      "value": 15
  },
  {
      "text": "fall",
      "value": 15
  },
  {
      "text": "heir",
      "value": 15
  },
  {
      "text": "promise",
      "value": 15
  },
  {
      "text": "yes",
      "value": 15
  },
  {
      "text": "well",
      "value": 15
  },
  {
      "text": "guaranteed",
      "value": 15
  },
  {
      "text": "unalienable",
      "value": 15
  },
  {
      "text": "pursuit",
      "value": 15
  },
  {
      "text": "happiness",
      "value": 15
  },
  {
      "text": "obvious",
      "value": 15
  },
  {
      "text": "defaulted",
      "value": 15
  },
  {
      "text": "insofar",
      "value": 15
  },
  {
      "text": "citizens",
      "value": 15
  },
  {
      "text": "concerned",
      "value": 15
  },
  {
      "text": "instead",
      "value": 15
  },
  {
      "text": "honoring",
      "value": 15
  },
  {
      "text": "sacred",
      "value": 15
  },
  {
      "text": "obligation",
      "value": 15
  },
  {
      "text": "given",
      "value": 15
  },
  {
      "text": "bad",
      "value": 15
  },
  {
      "text": "marked",
      "value": 15
  },
  {
      "text": "bank",
      "value": 15
  },
  {
      "text": "bankrupt",
      "value": 15
  },
  {
      "text": "vaults",
      "value": 15
  },
  {
      "text": "opportunity",
      "value": 15
  },
  {
      "text": "give",
      "value": 15
  },
  {
      "text": "demand",
      "value": 15
  },
  {
      "text": "riches",
      "value": 15
  },
  {
      "text": "security",
      "value": 15
  },
  {
      "text": "also",
      "value": 15
  },
  {
      "text": "hallowed",
      "value": 15
  },
  {
      "text": "spot",
      "value": 15
  },
  {
      "text": "remind",
      "value": 15
  },
  {
      "text": "fierce",
      "value": 15
  },
  {
      "text": "engage",
      "value": 15
  },
  {
      "text": "luxury",
      "value": 15
  },
  {
      "text": "cooling",
      "value": 15
  },
  {
      "text": "take",
      "value": 15
  },
  {
      "text": "tranquilizing",
      "value": 15
  },
  {
      "text": "drug",
      "value": 15
  },
  {
      "text": "gradualism",
      "value": 15
  },
  {
      "text": "real",
      "value": 15
  },
  {
      "text": "promises",
      "value": 15
  },
  {
      "text": "democracy",
      "value": 15
  },
  {
      "text": "dark",
      "value": 15
  },
  {
      "text": "desolate",
      "value": 15
  },
  {
      "text": "sunlit",
      "value": 15
  },
  {
      "text": "path",
      "value": 15
  },
  {
      "text": "lift",
      "value": 15
  },
  {
      "text": "quick",
      "value": 15
  },
  {
      "text": "sands",
      "value": 15
  },
  {
      "text": "solid",
      "value": 15
  },
  {
      "text": "rock",
      "value": 15
  },
  {
      "text": "reality",
      "value": 15
  },
  {
      "text": "fatal",
      "value": 15
  },
  {
      "text": "overlook",
      "value": 15
  },
  {
      "text": "moment",
      "value": 15
  },
  {
      "text": "summer",
      "value": 15
  },
  {
      "text": "legitimate",
      "value": 15
  },
  {
      "text": "discontent",
      "value": 15
  },
  {
      "text": "pass",
      "value": 15
  },
  {
      "text": "invigorating",
      "value": 15
  },
  {
      "text": "autumn",
      "value": 15
  },
  {
      "text": "equality",
      "value": 15
  },
  {
      "text": "nineteen",
      "value": 15
  },
  {
      "text": "sixty-three",
      "value": 15
  },
  {
      "text": "beginning",
      "value": 15
  },
  {
      "text": "needed",
      "value": 15
  },
  {
      "text": "blow",
      "value": 15
  },
  {
      "text": "steam",
      "value": 15
  },
  {
      "text": "rude",
      "value": 15
  },
  {
      "text": "awakening",
      "value": 15
  },
  {
      "text": "returns",
      "value": 15
  },
  {
      "text": "business",
      "value": 15
  },
  {
      "text": "usual",
      "value": 15
  },
  {
      "text": "neither",
      "value": 15
  },
  {
      "text": "rest",
      "value": 15
  },
  {
      "text": "tranquility",
      "value": 15
  }
]
