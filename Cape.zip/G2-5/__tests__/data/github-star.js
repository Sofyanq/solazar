// Data is collected by the end of 2022.11.09
export const githubStar = [
  { name: 'G', star: 814 },
  { name: 'G2', star: 11425 },
  { name: 'G2Plot', star: 2320 },
  { name: 'S2', star: 968 },
  { name: 'F2', star: 7346 },
  { name: 'L7', star: 2888 },
  { name: 'G6', star: 9314 },
  { name: 'X6', star: 3985 },
  { name: 'AVA', star: 1151 },
];
