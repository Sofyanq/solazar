export const points = [
  { x: -3, y: 7.5 },
  { x: -2, y: 3 },
  { x: -1, y: 0.5 },
  { x: 0, y: 1 },
  { x: 1, y: 3 },
  { x: 2, y: 6 },
  { x: 3, y: 14 },
];