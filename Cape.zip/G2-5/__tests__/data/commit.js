export const commit = [
  { name: 'MODIFY', value: 138, washaway: 0.21014492753623193 },
  { name: 'PRERELEASE', value: 109, washaway: 0.5596330275229358 },
  { name: 'RELEASING', value: 48, washaway: 0 },
];
