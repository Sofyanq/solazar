export const languages = [
  { id: 'c', value: 526 },
  { id: 'sass', value: 220 },
  { id: 'php', value: 325 },
  { id: 'elixir', value: 561 },
  { id: 'rust', value: 54 },
]